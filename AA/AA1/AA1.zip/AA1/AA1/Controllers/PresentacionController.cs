﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AA1.Data;
using AA1.Models;

namespace AA1.Controllers
{
    public class PresentacionController : Controller
    {
        private readonly AA1Context _context;

        public PresentacionController(AA1Context context)
        {
            _context = context;
        }

        // GET: Presentacion
        // GET: Presentacion
        public async Task<IActionResult> Index(string searchString, string sortOrder)
        {
            if (_context.Presentacion == null)
            {
                return Problem("Entity set 'AA1Context.Presentacion' is null.");
            }

            ViewData["DescripcionSortParm"] = String.IsNullOrEmpty(sortOrder) ? "descripcion_desc" : "";

            var presentacion = from m in _context.Presentacion
                               select m;

            if (!String.IsNullOrEmpty(searchString))
            {
                presentacion = presentacion.Where(s => s.Descripcion!.ToUpper().Contains(searchString.ToUpper()));
            }

            // Ordenación
            switch (sortOrder)
            {
                case "descripcion_desc":
                    presentacion = presentacion.OrderByDescending(s => s.Descripcion);
                    break;
                default:
                    presentacion = presentacion.OrderBy(s => s.Descripcion);
                    break;
            }

            return View(await presentacion.ToListAsync());
        }


        // GET: Presentacion/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var presentacion = await _context.Presentacion
                .FirstOrDefaultAsync(m => m.Id == id);
            if (presentacion == null)
            {
                return NotFound();
            }

            return View(presentacion);
        }

        // GET: Presentacion/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Presentacion/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Descripcion")] Presentacion presentacion)
        {
            if (ModelState.IsValid)
            {
                _context.Add(presentacion);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(presentacion);
        }

        // GET: Presentacion/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var presentacion = await _context.Presentacion.FindAsync(id);
            if (presentacion == null)
            {
                return NotFound();
            }
            return View(presentacion);
        }

        // POST: Presentacion/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Descripcion")] Presentacion presentacion)
        {
            if (id != presentacion.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(presentacion);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PresentacionExists(presentacion.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(presentacion);
        }

        // GET: Presentacion/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var presentacion = await _context.Presentacion
                .FirstOrDefaultAsync(m => m.Id == id);
            if (presentacion == null)
            {
                return NotFound();
            }

            return View(presentacion);
        }

        // POST: Presentacion/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var presentacion = await _context.Presentacion.FindAsync(id);
            if (presentacion != null)
            {
                _context.Presentacion.Remove(presentacion);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PresentacionExists(int id)
        {
            return _context.Presentacion.Any(e => e.Id == id);
        }
    }
}
