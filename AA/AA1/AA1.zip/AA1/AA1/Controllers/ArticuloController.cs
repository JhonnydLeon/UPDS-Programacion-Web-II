﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AA1.Data;
using AA1.Models;

namespace AA1.Controllers
{
    public class ArticuloController : Controller
    {
        private readonly AA1Context _context;

        public ArticuloController(AA1Context context)
        {
            _context = context;
        }

        // GET: Articulo
        // GET: Articulo
        public async Task<IActionResult> Index(string articuloCate, string searchString, string sortOrder)
        {
            if (_context.Articulo == null)
            {
                return Problem("Entity set 'AA1Context.Articulo' is null.");
            }

            // Obtener las categorías disponibles para filtrar
            IQueryable<string> categoriaQuery = from c in _context.Categoria
                                                orderby c.Descripcion
                                                select c.Descripcion;

            // Comenzar la consulta de artículos
            var articulos = from a in _context.Articulo
                            .Include(a => a.Categoria)  // Incluir la relación con Categoria
                            .Include(a => a.Presentacion)  // Incluir la relación con Presentacion
                            select a;

            // Filtrar por la descripción del artículo si el usuario ingresó algo en el campo de búsqueda
            if (!string.IsNullOrEmpty(searchString))
            {
                articulos = articulos.Where(s => s.Descripcion.ToUpper().Contains(searchString.ToUpper()));
            }

            // Filtrar por la categoría seleccionada
            if (!string.IsNullOrEmpty(articuloCate))
            {
                articulos = articulos.Where(x => x.Categoria.Descripcion == articuloCate);
            }

            // Ordenación por CodBarra
            ViewData["CodBarraSortParm"] = String.IsNullOrEmpty(sortOrder) ? "codbarra_desc" : ""; // Si no hay orden, empieza con orden descendente

            switch (sortOrder)
            {
                case "codbarra_desc":
                    articulos = articulos.OrderByDescending(a => a.CodBarra); // Orden descendente
                    break;
                default:
                    articulos = articulos.OrderBy(a => a.CodBarra); // Orden ascendente
                    break;
            }

            // Crear el ViewModel con los datos necesarios
            var articuloCateVM = new ArticuloCateViewModel
            {
                Categorias = new SelectList(await categoriaQuery.Distinct().ToListAsync()), // Lista de categorías disponibles
                Articulos = await articulos.ToListAsync(), // Artículos filtrados y ordenados
                SelectedCategoria = articuloCate, // Categoría seleccionada
                SearchString = searchString // Término de búsqueda
            };

            return View(articuloCateVM);
        }





        // GET: Articulo/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var articulo = await _context.Articulo
                .Include(a => a.Categoria)
                .Include(a => a.Presentacion)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (articulo == null)
            {
                return NotFound();
            }

            return View(articulo);
        }

        // GET: Articulo/Create
        public IActionResult Create()
        {
            ViewData["IdCategoria"] = new SelectList(_context.Categoria, "Id", "Descripcion");
            ViewData["IdPresentacion"] = new SelectList(_context.Presentacion, "Id", "Descripcion");
            return View();
        }

        // POST: Articulo/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,CodBarra,Descripcion,Imagen,IdCategoria,IdPresentacion")] Articulo articulo)
        {
            if (ModelState.IsValid)
                Console.WriteLine($"Datos Recibidos: CodBarra={articulo.CodBarra}, Descripcion={articulo.Descripcion}, Categoria={articulo.IdCategoria}, Presentacion={articulo.IdPresentacion}");

            {
                _context.Add(articulo);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdCategoria"] = new SelectList(_context.Categoria, "Id", "Descripcion", articulo.IdCategoria);
            ViewData["IdPresentacion"] = new SelectList(_context.Presentacion, "Id", "Descripcion", articulo.IdPresentacion);
            return View(articulo);
        }

        // GET: Articulo/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var articulo = await _context.Articulo.FindAsync(id);
            if (articulo == null)
            {
                return NotFound();
            }
            ViewData["IdCategoria"] = new SelectList(_context.Categoria, "Id", "Descripcion", articulo.IdCategoria);
            ViewData["IdPresentacion"] = new SelectList(_context.Presentacion, "Id", "Descripcion", articulo.IdPresentacion);
            return View(articulo);
        }

        // POST: Articulo/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,CodBarra,Descripcion,Imagen,IdCategoria,IdPresentacion")] Articulo articulo)
        {
            if (id != articulo.Id)

            {
                return NotFound();
            }

              
            if (!ModelState.IsValid)
            {
                try
                {
                    _context.Update(articulo);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ArticuloExists(articulo.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdCategoria"] = new SelectList(_context.Categoria, "Id", "Descripcion", articulo.IdCategoria);
            ViewData["IdPresentacion"] = new SelectList(_context.Presentacion, "Id", "Descripcion", articulo.IdPresentacion);
            return View(articulo);
        }

        // GET: Articulo/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var articulo = await _context.Articulo
                .Include(a => a.Categoria)
                .Include(a => a.Presentacion)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (articulo == null)
            {
                return NotFound();
            }

            return View(articulo);
        }

        // POST: Articulo/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var articulo = await _context.Articulo.FindAsync(id);
            if (articulo != null)
            {
                _context.Articulo.Remove(articulo);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ArticuloExists(int id)
        {
            return _context.Articulo.Any(e => e.Id == id);
        }
    }
}
