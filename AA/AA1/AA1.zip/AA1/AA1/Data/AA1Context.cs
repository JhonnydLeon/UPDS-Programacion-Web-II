﻿using AA1.Models;
using Microsoft.EntityFrameworkCore;

namespace AA1.Data
{
    public class AA1Context : DbContext
    {
        public AA1Context(DbContextOptions<AA1Context> options)
            : base(options)
        {
        }

        public DbSet<AA1.Models.Movie> Movie { get; set; } = default!;
        public DbSet<AA1.Models.Categoria> Categoria { get; set; } = default!;
        public DbSet<AA1.Models.Presentacion> Presentacion { get; set; } = default!;
        public DbSet<AA1.Models.Articulo> Articulo { get; set; } = default!;


        //Add-Migration actividad1
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configuración explícita de claves foráneas
            modelBuilder.Entity<Articulo>()
                .HasOne(a => a.Categoria)
                .WithMany(c => c.Articulos)
                .HasForeignKey(a => a.IdCategoria)
                .OnDelete(DeleteBehavior.Cascade); // Aseguramos la integridad referencial

            modelBuilder.Entity<Articulo>()
                .HasOne(a => a.Presentacion)
                .WithMany(p => p.Articulos)
                .HasForeignKey(a => a.IdPresentacion)
                .OnDelete(DeleteBehavior.Cascade); // Aseguramos la integridad referencial
        }



    }
}
