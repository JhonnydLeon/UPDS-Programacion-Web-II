﻿using System.ComponentModel.DataAnnotations;

namespace AA1.Models
{
    public class Categoria
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]  // Longitud máxima para la descripción
        public string Descripcion { get; set; }  // El campo no será null debido a [Required] y [StringLength]

        // Relación con Articulo (uno a muchos)
        public ICollection<Articulo> Articulos { get; set; } = new List<Articulo>();
    }
}
