﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AA1.Models
{
    public class Articulo
    {
        public int Id { get; set; }

        [Required]  // El campo CodBarra es obligatorio
        [StringLength(50)]  // Longitud máxima para CodBarra
        public string CodBarra { get; set; }

        [Required]  // El campo Descripcion es obligatorio
        [StringLength(100)]  // Longitud máxima para Descripcion
        public string Descripcion { get; set; }

        public string? Imagen { get; set; }  // Este campo es opcional

        [Required]  // Relación obligatoria con Categoria
        public int IdCategoria { get; set; }

        // Relación con Categoria
        [ForeignKey("IdCategoria")]  // Especifica explícitamente la clave foránea
        public Categoria Categoria { get; set; }

        [Required]  // Relación obligatoria con Presentacion
        public int IdPresentacion { get; set; }

        // Relación con Presentacion
        [ForeignKey("IdPresentacion")]  // Especifica explícitamente la clave foránea
        public Presentacion Presentacion { get; set; }
    }
}
