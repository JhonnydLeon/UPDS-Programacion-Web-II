﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace AA1.Models
{
    public class ArticuloCateViewModel
    {
        // Lista de artículos que se mostrarán en la vista
        public List<Articulo>? Articulos { get; set; }

        // Lista de categorías disponibles para el filtro
        public SelectList? Categorias { get; set; }

        // Categoría seleccionada para el filtro
        public string? SelectedCategoria { get; set; }

        // Término de búsqueda para los artículos
        public string? SearchString { get; set; }
    }
}
