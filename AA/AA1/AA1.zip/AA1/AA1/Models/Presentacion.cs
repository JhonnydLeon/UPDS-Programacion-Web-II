﻿using System.ComponentModel.DataAnnotations;

namespace AA1.Models
{
    public class Presentacion
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]  // Especifica la longitud máxima para la descripción, puedes ajustarla según tu caso.
        public string Descripcion { get; set; }  // El campo no será null debido a [Required] y StringLength.

        // Relación con Articulo (uno a muchos)
        public ICollection<Articulo> Articulos { get; set; } = new List<Articulo>();
    }
}
