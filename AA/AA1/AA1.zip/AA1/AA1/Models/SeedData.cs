﻿using AA1.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using AA1.Data;
using System;
using System.Linq;

namespace AA1.Models;

public static class SeedData
{
    public static void Initialize(IServiceProvider serviceProvider)
    {
        using (var context = new AA1Context(
            serviceProvider.GetRequiredService<
                DbContextOptions<AA1Context>>()))
        {
            // Look for any movies.
            if (context.Presentacion.Any())
            {
                return;   // DB has been seeded
            }
            context.Presentacion.AddRange(
                new Presentacion
                {
                    Descripcion = "When Harry Met Sally",
                    
                },
                new Presentacion
                {
                    Descripcion = "Ghostbusters ",
                    
                },
                new Presentacion
                {
                    Descripcion = "Ghostbusters 2",
                    
                },
                new Presentacion
                {
                    Descripcion = "Rio Bravo",
                   
                }
            );
            context.SaveChanges();
        }
    }
}